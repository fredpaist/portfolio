<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 26.04.2016
 * Time: 20:30
 */

?>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js"></script>
  </body>
</html>