<?php

/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 26.04.2016
 * Time: 20:31
 */

require_once 'include/start.php';
/*Filter võimaluste muutujad*/
$filter_sugu = filter_input(INPUT_POST,'sugu', FILTER_SANITIZE_STRING);
$vahend = filter_input(INPUT_POST,'vahend', FILTER_SANITIZE_STRING);
/*Data for charts*/
$sugu = Querys::get_data('Sugu', $filter_sugu, $vahend);
$vanus = Querys::get_data('Vanus',  $filter_sugu, $vahend);
$igapaevane_liikumine = Querys::get_data('igapaevane_liikumine',  $filter_sugu, $vahend);
$liikumise_eesmargid = Querys::get_data('liikumise_eesmargid',  $filter_sugu, $vahend);
$teekonna_olulisus = Querys::get_data('liikumisteekonna_olulisus',  $filter_sugu, $vahend);
$jalgrattaga_liikumine = Querys::get_data('jalgrattaga_liikumine',  $filter_sugu, $vahend);
$jala_liikumine = Querys::get_data('jala_liikumine',  $filter_sugu, $vahend);
$igapaevane_liikumine_umb = Querys::get_data('igapaevane_liikumine_umb',  $filter_sugu, $vahend);
$fyysilise_aktiivsuse_olulisus = Querys::get_data('fyysilise_aktiivsuse_olulisus',  $filter_sugu, $vahend);
$sport = Querys::get_data('fyysilise_aktiivsuse_harrastus',  $filter_sugu, $vahend);

require_once 'template/header.php';
?>
    <!--Google Charts funktsioon-->
   <script type="text/javascript"> 
        google.charts.load('current', {'packages': ['corechart']}); 
        google.charts.setOnLoadCallback(drawChart);
        
       function drawChart() {
           //kutsub "chart" funktsiooni et joonistada meile graafikud
           <?php $sugu_chart = chart($sugu, 1, 'Osavõtjad', 'PieChart', 'sugu_chart');
            echo $sugu_chart;
           $vanus_chart = chart($vanus, 2, 'Vanus', 'PieChart', 'vanus_chart');
            echo $vanus_chart;
           $igapaevane_liikumine_chart = chart($igapaevane_liikumine, 3, 'Peamine liikumise vahend', 'PieChart', 'igapaevane_liikumine');
            echo $igapaevane_liikumine_chart;
            $teekonna_olulisus_chart = chart($teekonna_olulisus, 5, 'Mis on liikumis teekonnal olulist?', 'PieChart', 'teekonna_olulisus');
            echo $teekonna_olulisus_chart;
            $jalgrattaga_liikumine_chart = chart($jalgrattaga_liikumine, 6, 'Kui tihti liigutakse jalgrattaga 5 palli süsteemis', 'ColumnChart', 'jalgrattaga_liikumine');
            echo $jalgrattaga_liikumine_chart;
            $jala_liikumine_chart = chart($jala_liikumine, 7, 'Kui tihti liigutakse jala 5 palli süsteemis', 'ColumnChart', 'jala_liikumine');
            echo $jala_liikumine_chart;
             $igapaevane_liikumine_umb_chart = chart($igapaevane_liikumine_umb, 8, 'Mitu kilomeetrit liigutakse umbes igapäevaselt', 'BarChart', 'umb_liikumine');
            echo $igapaevane_liikumine_umb_chart;
            $fyysilise_aktiivsuse_olulisus_chart = chart($fyysilise_aktiivsuse_olulisus, 9, 'Kui oluliseks peetakse füüsilist aktiivsust', 'PieChart', 'fyysiline_liikumine');
            echo $fyysilise_aktiivsuse_olulisus_chart;
            $sport_chart = chart($sport, 10, 'Kui tihti tehakse sporti', 'ColumnChart', 'sport');
            echo $sport_chart;?>
            }

    </script>
    <div class="container">
    <h1 class="page-header">Inimeste liikumisharjumused</h1>
        <div class="row">
            <!--Filter võimalus vormina-->
            <div class="col col-md-4 col-xs-12">
                <h4>Vali mille järgi soovid vastuseid näha</h4>
                <div class="form-group">
                    <label>Sugu</label>
                    <form method="post">
                    <select class="form-control" id="sugu" name="sugu">
                      <option value="">Mõlemad</option>
                      <option value="Mees">Mees</option>
                      <option value="Naine">Naine</option>
                    </select>
                    <label for="sel1">Peamine liikumisvahend</label>
                    <select  class="form-control" id="transport" name="vahend">
                      <option value="">Kõik</option>
                      <option value="Auto">Auto</option>
                      <option value="Ratas">Ratas</option>
                      <option value="Ühistransport">Ühistransport</option>
                      <option value="Jala">Jala</option>
                    </select>
                    <button type="submit" class="btn btn-default" id="btn">Valmis</button>
                    </form>
              </div>
        </div>
    </div>
    <!--Filter võimaluse lõpp-->
    <!--graafikute asukohad-->
    <div class="container-fluid">
        <div class="chart_wrapper">
            <div class="chart" id="sugu_chart"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="vanus_chart"></div
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="igapaevane_liikumine"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="teekonna_olulisus"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="jalgrattaga_liikumine"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="jala_liikumine"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="umb_liikumine"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="fyysiline_liikumine"></div>
        </div>
        <div class="chart_wrapper">
        <div class="chart" id="sport"></div>
        </div>
    </div>
</div>

    <script type="text/javascript">
        //kui filter võimalus on valitud, siis jätab selle valiku nähtavale
       document.getElementById('sugu').value = "<?php echo $filter_sugu;?>";
        document.getElementById('transport').value = "<?php echo $vahend;?>";
        // kui akna suurust muudetakse,
        // siis muudetakse ka Chartide suurust joonistades need uute suurustega
        window.addEventListener('resize', function(event){
            drawChart();
        });    
    </script>
<?php
require_once 'template/footer.php';