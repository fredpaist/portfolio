<?php
/*function for greating charts*/

function chart($data, $nr, $title, $chart, $id){
    
    $r= "var data".$nr."= google.visualization.arrayToDataTable([ 
                ['teema', 'Vastajad']";
    
    foreach($data as $code){ 
     $r.=   ",['" .$code->data."', ".$code->num."]";
     }                         
     $r.=      " ]); 

            var options".$nr."= { 
                title: '".$title."',
                is3D: true,
                width: '100%',
                height: '100%',
            }; 

            var chart".$nr."= new google.visualization.".$chart."(document.getElementById('".$id."')); 

            chart".$nr.".draw(data".$nr.", options".$nr.");";
     
    return $r;
}
