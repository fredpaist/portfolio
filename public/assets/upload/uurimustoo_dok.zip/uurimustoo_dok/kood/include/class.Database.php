<?php

/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 27.04.2016
 * Time: 13:48
 */

/*Class for database connection*/
class Database
{
    private $mysql;

    public function __construct()
    {
        $this->mysqli = new mysqli("localhost", "TA-15_Mikk", "qwerty", "TA-15_Mikk");
          $this->mysqli->set_charset("utf8");
        /* check connection */
        if ($this->mysqli->connect_errno) {
            printf("Connect failed: %s\n", $this->mysqli->connect_error);
            exit();
        }

    }

    public function query($sql){

        $result = $this->mysqli->query($sql, MYSQLI_USE_RESULT);

        $results = [];
        while($row = $result->fetch_object()) {

            $results[] = $row;
        }

        return $results;
    }
}

$db = new Database();
/*Class for getting chart data from database */
class Querys{
    public $data;
    public $count;


    public static function get_data($column, $sugu='', $vahend=''){
        global $db;
    $sql = "SELECT DISTINCT(`".$column."`)"
            . " AS data,"
            . "count(`".$column."`) AS num"
            . " FROM `TA15_uurimus`";
            if(!empty($sugu) || !empty($vahend)){
            $sql.= " WHERE ";
              if(!empty($sugu)){
            $sql.=  "Sugu='".$sugu."'";    
              }
              if(!empty($sugu) && !empty($vahend)){
            $sql.=" AND ";      
              }
              if(!empty($vahend)){
            $sql.= "igapaevane_liikumine='".$vahend."'";      
              }
            }
            $sql.= " GROUP BY `".$column."`;";

     $results = $db->query($sql);
        return empty($results) ? false : $results;
    }

}