<?php

defined('DS') ? NULL : define('DS', DIRECTORY_SEPARATOR);


defined('MAIN_URL') ? NULL : define('MAIN_URL', 'http://ubunts.ametikool.ee/~TA-15_Fred/uurimus/');
defined('MAIN_PATH') ? NULL : define('MAIN_PATH', DS. 'home' .DS. 'TA-15_Fred' .DS. 'public_html' .DS.'uurimus' .DS);

defined('TEMPLATE_URL') ? NULL : define('TEMPLATE_URL', MAIN_URL . 'template/');
defined('TEMPLATE_PATH') ? NULL : define('TEMPLATE_PATH', MAIN_PATH . 'template' . DS);


require_once MAIN_PATH . 'include' . DS . 'functions.php';
require_once MAIN_PATH . 'include' . DS . 'class.Database.php';
