-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Loomise aeg: Mai 30, 2016 kell 05:24 PM
-- Serveri versioon: 5.6.25-1~dotdeb+7.1
-- PHP versioon: 5.6.17-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Andmebaas: `TA-15_Mikk`
--

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `TA15_uurimus`
--

CREATE TABLE IF NOT EXISTS `TA15_uurimus` (
  `Sugu` char(6) NOT NULL,
  `Vanus` varchar(5) NOT NULL,
  `igapaevane_liikumine` varchar(255) NOT NULL,
  `liikumise_eesmargid` varchar(255) NOT NULL,
  `liikumisteekonna_olulisus` varchar(255) NOT NULL,
  `jalgrattaga_liikumine` int(1) NOT NULL,
  `jala_liikumine` int(1) NOT NULL,
  `igapaevane_liikumine_umb` int(2) NOT NULL,
  `fyysilise_aktiivsuse_olulisus` varchar(255) NOT NULL,
  `fyysilise_aktiivsuse_harrastus` varchar(255) NOT NULL,
`ID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=latin1;

--
-- Andmete tõmmistamine tabelile `TA15_uurimus`
--

INSERT INTO `TA15_uurimus` (`Sugu`, `Vanus`, `igapaevane_liikumine`, `liikumise_eesmargid`, `liikumisteekonna_olulisus`, `jalgrattaga_liikumine`, `jala_liikumine`, `igapaevane_liikumine_umb`, `fyysilise_aktiivsuse_olulisus`, `fyysilise_aktiivsuse_harrastus`, `ID`) VALUES
('Naine', '22-25', 'Jala', 'Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 2, 5, 5, 'Vajalik', 'Paar korda kuus', 91),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks', 'Ilu/loodusrikas ümbruskond', 2, 4, 2, 'Vajalik', 'Mitu korda nädalas', 92),
('Mees', '26-30', 'Jala', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 3, 5, 2, 'Väga oluliseks', 'Igapäev', 93),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 3, 2, 'Väga oluliseks', 'Mitu korda nädalas', 94),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 3, 1, 'Väga oluliseks', 'Mitu korda nädalas', 95),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks', 'Ilu/loodusrikas ümbruskond', 3, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 96),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 3, 4, 5, 'Väga oluliseks', 'Mitu korda nädalas', 97),
('Naine', '22-25', 'Auto', 'Niisama väljas käimisel', 'Et oleks võimalikult kiire', 1, 3, 2, 'Nii ja naa', 'Iga nädal', 98),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 2, 'Väga oluliseks', 'Iga nädal', 99),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Ilu/loodusrikas ümbruskond', 4, 5, 10, 'Väga oluliseks', 'Mitu korda nädalas', 100),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 3, 3, 2, 'Väga oluliseks', 'Mitu korda nädalas', 101),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 3, 5, 2, 'Väga oluliseks', 'Mitu korda nädalas', 102),
('Naine', '26-30', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 5, 1, 'Vajalik', 'Mitu korda nädalas', 103),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Ei oleks liialt palju liiklust', 2, 4, 10, 'Väga oluliseks', 'Mitu korda nädalas', 104),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 2, 1, 'Vajalik', 'Iga nädal', 105),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 4, 5, 'Väga oluliseks', 'Mitu korda nädalas', 106),
('Mees', '22-25', 'Auto', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 3, 3, 2, 'Vajalik', 'Iga nädal', 107),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 1, 'Vajalik', 'Iga nädal', 108),
('Naine', '14-17', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 5, 2, 'Väga oluliseks', 'Mitu korda nädalas', 109),
('Naine', '14-17', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 3, 4, 5, 'Väga oluliseks', 'Mitu korda nädalas', 110),
('Naine', '31+', 'Jala', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 5, 5, 'Vajalik', 'Paar korda kuus', 111),
('Mees', '31+', 'Auto', 'Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 3, 2, 'Nii ja naa', 'Iga nädal', 112),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 3, 4, 5, 'Vajalik', 'Mitu korda nädalas', 113),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 3, 3, 2, 'Vajalik', 'Mitu korda nädalas', 114),
('Naine', '14-17', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 3, 5, 10, 'Väga oluliseks', 'Igapäev', 115),
('Mees', '18-21', 'Jala', 'Trenni eesmärgil', 'Ei oleks liialt palju liiklust', 1, 5, 5, 'Väga oluliseks', 'Igapäev', 116),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 4, 5, 5, 'Vajalik', 'Mitte kunagi', 117),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 118),
('Naine', '22-25', 'Ühistransport', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 1, 5, 10, 'Väga oluliseks', 'Mitu korda nädalas', 119),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil, Ostlemiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 2, 5, 2, 'Väga oluliseks', 'Igapäev', 120),
('Naine', '22-25', 'Jala', 'Trenni eesmärgil, Ostlemiseks', 'Teekond oleks tuttav', 2, 5, 1, 'Vajalik', 'Mitu korda nädalas', 121),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 5, 5, 'Väga oluliseks', 'Iga nädal', 122),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 1, 5, 5, 'Vajalik', 'Iga nädal', 123),
('Naine', '14-17', 'Auto', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 3, 4, 2, 'Vajalik', 'Igapäev', 124),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks', 'Et oleks võimalikult kiire', 2, 5, 2, 'Vajalik', 'Iga nädal', 125),
('Naine', '22-25', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 5, 2, 'Väga oluliseks', 'Igapäev', 126),
('Naine', '22-25', 'Auto', 'Trenni eesmärgil, Ostlemiseks', 'Ilu/loodusrikas ümbruskond', 2, 4, 2, 'Vajalik', 'Mitu korda nädalas', 127),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks, Trenni eesmärgil, Ostlemiseks', 'Et oleks võimalikult kiire', 3, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 128),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks', 'Et oleks võimalikult kiire', 1, 3, 1, 'Väga oluliseks', 'Mitu korda nädalas', 129),
('Mees', '22-25', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 1, 5, 5, 'Vajalik', 'Igapäev', 130),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks, Trenni eesmärgil, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 3, 4, 2, 'Väga oluliseks', 'Igapäev', 131),
('Naine', '18-21', 'Ratas', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 5, 5, 2, 'Vajalik', 'Iga nädal', 132),
('Mees', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Ei oleks liialt palju liiklust', 4, 3, 5, 'Nii ja naa', 'Iga nädal', 133),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 2, 3, 2, 'Vajalik', 'Paar korda kuus', 134),
('Mees', '22-25', 'Jala', 'Trenni eesmärgil, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 2, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 135),
('Naine', '18-21', 'Auto', 'Ostlemiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 3, 4, 2, 'Vajalik', 'Mitu korda nädalas', 136),
('Mees', '18-21', 'Jala', 'Niisama väljas käimisel', 'Et oleks võimalikult kiire', 3, 5, 5, 'Väga oluliseks', 'Igapäev', 137),
('Mees', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 1, 5, 1, 'Vajalik', 'Igapäev', 138),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 1, 5, 2, 'Vajalik', 'Paar korda kuus', 139),
('Naine', '31+', 'Jala', 'Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 1, 5, 5, 'Väga oluliseks', 'Igapäev', 140),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 2, 5, 5, 'Väga oluliseks', 'Igapäev', 141),
('Mees', '14-17', 'Ratas', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ei oleks liialt palju liiklust', 5, 5, 2, 'Väga oluliseks', 'Igapäev', 142),
('Naine', '22-25', 'Jala', 'Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 2, 5, 5, 'Vajalik', 'Mitu korda nädalas', 143),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 2, 5, 2, 'Väga oluliseks', 'Igapäev', 144),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 3, 5, 'Väga oluliseks', 'Mitu korda nädalas', 145),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 1, 'Vajalik', 'Paar korda kuus', 146),
('Naine', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Teekond oleks tuttav', 2, 5, 2, 'Vajalik', 'Iga nädal', 147),
('Mees', '31+', 'Auto', 'Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 2, 1, 'Nii ja naa', 'Paar korda kuus', 149),
('Naine', '22-25', 'Ühistransport', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 4, 4, 0, 'Väga oluliseks', 'Paar korda kuus', 150),
('Naine', '31+', 'Jala', 'Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 3, 5, 2, 'Väga oluliseks', 'Igapäev', 151),
('Naine', '14-17', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 4, 5, 2, 'Vajalik', 'Iga nädal', 153),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks', 'Ilu/loodusrikas ümbruskond', 4, 4, 5, 'Väga oluliseks', 'Igapäev', 154),
('Naine', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 3, 5, 'Väga oluliseks', 'Mitu korda nädalas', 155),
('Naine', '22-25', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 5, 2, 'Vajalik', 'Igapäev', 156),
('Mees', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 2, 1, 'Väga oluliseks', 'Paar korda kuus', 157),
('Mees', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 4, 1, 'Väga oluliseks', 'Mitu korda nädalas', 158),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks', 'Ei oleks liialt palju liiklust', 2, 4, 5, 'Vajalik', 'Iga nädal', 159),
('Naine', '31+', 'Jala', 'Tööl/koolis käimiseks', 'Ilu/loodusrikas ümbruskond', 5, 5, 2, 'Väga oluliseks', 'Paar korda kuus', 160),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 1, 'Vajalik', 'Iga nädal', 161),
('Mees', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 4, 5, 'Väga oluliseks', 'Iga nädal', 162),
('Naine', '31+', 'Jala', 'Trenni eesmärgil, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 5, 5, 'Väga oluliseks', 'Igapäev', 163),
('Naine', '31+', 'Jala', 'Trenni eesmärgil, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 5, 5, 'Väga oluliseks', 'Igapäev', 164),
('Mees', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 4, 4, 5, 'Vajalik', 'Mitu korda nädalas', 165),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 3, 5, 2, 'Vajalik', 'Iga nädal', 166),
('Mees', '26-30', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks', 'Ei oleks liialt palju liiklust', 1, 3, 10, 'Vajalik', 'Igapäev', 167),
('Mees', '26-30', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 5, 2, 'Nii ja naa', 'Paar korda kuus', 168),
('Naine', '18-21', 'Auto', 'Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 1, 3, 1, 'Nii ja naa', 'Paar korda kuus', 169),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 3, 5, 2, 'Väga oluliseks', 'Igapäev', 170),
('Naine', '22-25', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 2, 5, 5, 'Vajalik', 'Mitu korda nädalas', 171),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil, Niisama väljas käimisel', 'Teekond oleks tuttav', 1, 5, 5, 'Väga oluliseks', 'Iga nädal', 172),
('Naine', '18-21', 'Auto', 'Tööl/koolis käimiseks, Trenni eesmärgil, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 2, 5, 5, 'Vajalik', 'Iga nädal', 173),
('Mees', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 3, 2, 'Väga oluliseks', 'Mitu korda nädalas', 174),
('Naine', '31+', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks', 'Ei oleks liialt palju liiklust', 1, 5, 1, 'Väga oluliseks', 'Paar korda kuus', 175),
('Mees', '18-21', 'Auto', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 1, 5, 5, 'Vajalik', 'Paar korda kuus', 176),
('Mees', '22-25', 'Jala', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 5, 1, 'Väga oluliseks', 'Mitu korda nädalas', 177),
('Naine', '14-17', 'mopeed', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ei oleks liialt palju liiklust', 2, 3, 2, 'Väga oluliseks', 'Mitu korda nädalas', 179),
('Naine', '31+', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 5, 5, 10, 'Väga oluliseks', 'Igapäev', 180),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 1, 4, 10, 'Väga oluliseks', 'Igapäev', 181),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 3, 5, 5, 'Väga oluliseks', 'Igapäev', 182),
('Mees', '18-21', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks', 'Ilu/loodusrikas ümbruskond', 3, 4, 5, 'Vajalik', 'Mitu korda nädalas', 183),
('Naine', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 5, 5, 'Väga oluliseks', 'Igapäev', 184),
('Mees', '22-25', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 3, 5, 1, 'Nii ja naa', 'Mitte kunagi', 185),
('Mees', '18-21', 'Jala', 'Trenni eesmärgil', 'Turvalisus', 1, 3, 1, 'Väga oluliseks', 'Mitu korda nädalas', 186),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 2, 2, 10, 'Vajalik', 'Igapäev', 187),
('Naine', '22-25', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 2, 4, 2, 'Väga oluliseks', 'Mitu korda nädalas', 188),
('Naine', '31+', 'Jala', 'Tööl/koolis käimiseks', 'Teekond oleks tuttav', 4, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 189),
('Naine', '26-30', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Ilu/loodusrikas ümbruskond', 3, 5, 10, 'Väga oluliseks', 'Igapäev', 190),
('Naine', '22-25', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 1, 'Vajalik', 'Iga nädal', 191),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 3, 10, 'Nii ja naa', 'Igapäev', 192),
('Mees', '26-30', 'Auto', 'Tööl/koolis käimiseks, Ostlemiseks', 'Ei oleks liialt palju liiklust', 3, 3, 10, 'Vajalik', 'Iga nädal', 193),
('Naine', '18-21', 'Ühistransport', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 4, 10, 'Vajalik', 'Mitte kunagi', 194),
('Naine', '26-30', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 1, 4, 1, 'Vajalik', 'Mitu korda nädalas', 195),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Trenni eesmärgil', 'Et oleks võimalikult kiire', 1, 5, 5, 'Väga oluliseks', 'Mitu korda nädalas', 196),
('Mees', '31+', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Ilu/loodusrikas ümbruskond', 3, 4, 5, 'Väga oluliseks', 'Mitu korda nädalas', 197),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks, Ostlemiseks, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 3, 5, 2, 'Nii ja naa', 'Iga nädal', 198),
('Naine', '14-17', 'Ühistransport', 'Tööl/koolis käimiseks, Trenni eesmärgil, Niisama väljas käimisel', 'Ei oleks liialt palju liiklust', 3, 5, 2, 'Väga oluliseks', 'Igapäev', 199),
('Naine', '18-21', 'Jala', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 5, 5, 'Vajalik', 'Paar korda kuus', 200),
('Naine', '31+', 'Auto', 'Tööl/koolis käimiseks', 'Et oleks võimalikult kiire', 2, 5, 2, 'Väga oluliseks', 'Igapäev', 201),
('Naine', '22-25', 'Jala', 'Tööl/koolis käimiseks', 'Ei oleks liialt palju liiklust', 1, 5, 5, 'Vajalik', 'Igapäev', 202),
('Naine', '22-25', 'Jala', 'Tööl/koolis käimiseks, Niisama väljas käimisel', 'Et oleks võimalikult kiire', 3, 5, 2, 'Vajalik', 'Paar korda kuus', 203);

--
-- Indeksid tõmmistatud tabelitele
--

--
-- Indeksid tabelile `TA15_uurimus`
--
ALTER TABLE `TA15_uurimus`
 ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT tõmmistatud tabelitele
--

--
-- AUTO_INCREMENT tabelile `TA15_uurimus`
--
ALTER TABLE `TA15_uurimus`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=218;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
