<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 12:44
 */
require_once '../../include/autoload.php';
if(!$session->is_logged_in())redirect_to(ROOT_URL.'login.php');
$del = filter_input(INPUT_GET,'delete', FILTER_VALIDATE_INT);

if($del){
    $page = Pages::find_by_ID($del);
    $page->delete();
    redirect_to(ROOT_URL. 'admin/pages');
}

$headers =['ID', 'title', 'status', 'menu_title'];

$pages = Pages::find_all();

echo view('pages_list', 'admin')->with('headers', $headers)->with('items', $pages);