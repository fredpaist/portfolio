<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 12:47
 */
require_once '../../include/autoload.php';
if(!$session->is_logged_in())redirect_to(ROOT_URL.'login.php');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if($id){
    $page = Pages::find_by_ID($id);
    $edit = true;
}else{
    $page = new Pages();
    $edit = false;
}
$errors = [];
$install = filter_input(INPUT_POST, 'install', FILTER_VALIDATE_INT);

if($install){
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
    $menu_title = filter_input(INPUT_POST, 'menu_title', FILTER_SANITIZE_STRING);
    $url = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_STRING);

    if(empty($title)){
        $errors[] = 'title';
    }
    if(empty($content)){
        $errors[] = 'content missing';
    }
    if(empty($menu_title)){
        $errors[] = 'menu title missing';
    }
    if(empty($url)){
        $errors[] = 'url';
    }



    if(empty($errors))
    {
        $page->title = $title;

        $page->content = $content;
        $page->menu_title = $menu_title;
        $page->status = 1;
        $page->url = $url;
        if($edit){
            $page->edited = date("Y-m-d H:i:s");
        }else{
            $page->added = date("Y-m-d H:i:s");
            $page->edited = date("Y-m-d H:i:s");
        }

        $page->save();

        redirect_to(ROOT_URL. 'admin/pages');
    }

}

echo view('page_add', 'admin')->with('errors', $errors)->with('page', $page);