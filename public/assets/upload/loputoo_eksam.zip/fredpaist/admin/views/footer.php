<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 9:30
 */

?>
</div>

</body>

<!--   Core JS Files   -->
<script src="<?php echo TEMPLATE_URL ?>js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL ?>js/bootstrap.min.js" type="text/javascript"></script>

<!--  Checkbox, Radio & Switch Plugins -->
<script src="<?php echo TEMPLATE_URL ?>js/bootstrap-checkbox-radio.js"></script>

<!--  Charts Plugin -->
<script src="<?php echo TEMPLATE_URL ?>js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="<?php echo TEMPLATE_URL ?>js/bootstrap-notify.js"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<!--<script src="<?php echo TEMPLATE_URL ?>js/paper-dashboard.js"></script>-->

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo TEMPLATE_URL ?>js/demo.js"></script>

</html>
