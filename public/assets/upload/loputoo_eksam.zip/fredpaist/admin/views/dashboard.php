<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 11:44
 */
require_once 'header.php';

require_once 'sidebar.php';
?>

<div class="main-panel">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar bar1"></span>
                    <span class="icon-bar bar2"></span>
                    <span class="icon-bar bar3"></span>
                </button>
                <a class="navbar-brand" href="#">Dashboard</a>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="ti-bell"></i>
                            <p>me</p>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo MAIN_URL .'logout'?>">logout</a></li>
                        </ul>
                    </li>
                </ul>

            </div>
        </div>
    </nav>


    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <a href="<?php echo ROOT_URL .'admin/user' ?>">
                        <div class="card">
                            <div class="content">
                                <i class="ti-user"></i>
                                <p>Users</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <a href="<?php echo ROOT_URL .'admin/pages' ?>">
                        <div class="card">
                            <div class="content">
                                <i class="ti-list"></i>
                                <p>Pages</p>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
    </div>
</div>
    <?php require_once 'footer.php';

