<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 9:21
 */

require_once '../include/autoload.php';
if(!$session->is_logged_in())redirect_to(ROOT_URL.'login.php');

echo view('dashboard', 'admin');