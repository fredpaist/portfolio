<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 9:25
 */
require_once 'definer.php';


require_once CLASS_PATH . 'functions.php';

if(file_exists(CLASS_PATH. 'config.php')){
    require_once CLASS_PATH. 'config.php';
    require_once CLASS_PATH . 'class.MysqlConnection.php';
    require_once CLASS_PATH . 'class.DatabaseQuery.php';
    require_once CLASS_PATH . 'class.Session.php';
    require_once CLASS_PATH . 'class.User.php';
    require_once CLASS_PATH . 'class.Pages.php';
}

//Dynamic classes
require_once CLASS_PATH . 'class.View.php';


