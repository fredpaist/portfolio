<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 10:16
 */

return "CREATE TABLE ". DB_PREFIX."pages (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        url  VARCHAR(50) NOT NULL,
        title  VARCHAR(50) NOT NULL,
        content TEXT  NOT NULL,
        added  DATETIME,
        edited TIMESTAMP,
        menu_title VARCHAR(50),
        status int(1)
        )";