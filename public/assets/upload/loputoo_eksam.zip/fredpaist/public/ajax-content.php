<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 13:10
 */

require_once '../include/autoload.php';

$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
$url = filter_input(INPUT_POST, 'data', FILTER_SANITIZE_STRING);

if($action){
    $hash = str_replace('#', '', $url);

    $page = Pages::find_by_name($hash);
	
	if(empty($page))
	{
		$page = Pages::find_by_name('/');
	}

   echo json_encode($page);
}