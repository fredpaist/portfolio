/**
 * Created by fred.paist on 16.05.2017.
 */

$(document).ready(function(){
	getdata();
	
	window.onhashchange = getdata;
    
});

function getdata()
{
	var url = window.location.hash;
    console.log(url);

    var data = {
        action: 'content',
        data : url
    }
    $.post('ajax-content.php', data, function(data){
        console.log(data);
        var data = jQuery.parseJSON(data);
        $('.cover-heading').html(data.title);
        $('.lead').html(data.content);
    })
}