<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 13:06
 */
require_once 'header.php';
?>
    <div class="site-wrapper">

        <div class="site-wrapper-inner">

            <div class="cover-container">

                <div class="masthead clearfix">
                    <div class="inner">
                        <h3 class="masthead-brand">Cover</h3>
                        <nav>
                            <ul class="nav masthead-nav">
                                <?php if($session->is_logged_in()) :?>
                                    <li class="active"><a href="logout.php">logout</a></li>
                                <?php else : ?>
                                <li class="active"><a href="login.php">Login</a></li>
                                <?php endif; ?>
                                <?php foreach ($pages as $link) : ?>
                                <li><a href="<?php echo MAIN_URL.'#'. $link->url ?>"><?php echo $link->menu_title ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </nav>
                    </div>
                </div>

                <div class="inner cover">
                    <h1 class="cover-heading">Cover your page.</h1>
                    <p class="lead">Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add your own fullscreen background photo to make it your own.</p>
                </div>

                <div class="mastfoot">
                    <div class="inner">
                        <p>Cover template for <a href="http://getbootstrap.com">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
                    </div>
                </div>

            </div>

        </div>

    </div

<?php
require_once 'footer.php';
