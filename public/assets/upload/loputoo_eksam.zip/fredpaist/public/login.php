<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 11:47
 */
require_once '../include/autoload.php';
if($session->is_logged_in())redirect_to(ROOT_URL.'admin');

$errors = [];
$install = filter_input(INPUT_POST, 'install', FILTER_VALIDATE_INT);
global $database;

if($install && !isset($_SESSION['noLogin'])){
	
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
    $pw = filter_input(INPUT_POST, 'pw', FILTER_SANITIZE_STRING);
	
    if(empty($email)){
        $errors[] = 'email vajalik';
    }
    if(empty($pw)){
        $errors[] = 'parool vajalik';
    }


    if(empty($errors)){
        $auth = new User();

        if($auth->auth($email, $pw)) {
            redirect_to(ROOT_URL.'admin/');
        } else {
            $errors[] = 'failed to log in';
             if(!isset($_SESSION['failed'])){
				 $_SESSION['failed'] = 1;
			 }else{
				 $_SESSION['failed'] += 1;
			 }
        }
    }
	
	if(isset($_SESSION['failed']) && $_SESSION['failed'] >= 3){
		$log = date("Y-m-d H:i:s")." - ". get_ip(). ' - failed to login';
		setLog($log);
		$_SESSION['noLogin'] = true;
 	}

}
if(isset($_SESSION['failed']) && $_SESSION['failed'] >= 3){
	$errors['ip'] = 'your IP session has been blocked due to too many fails';
}


echo view('login', 'public')->with('errors', $errors);