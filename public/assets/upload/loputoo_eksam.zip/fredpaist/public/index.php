<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 11:49
 */
require_once '../include/autoload.php';

$pages = Pages::find_all();

echo view('content', 'public')->with('pages', $pages)->with('session', $session);