<?php
/**
 * Created by PhpStorm.
 * User: fred.paist
 * Date: 16.05.2017
 * Time: 9:20
 */

require_once 'include/autoload.php';

if(!file_exists('include/config.php'))redirect_to(ROOT_URL.'admin/install.php');


redirect_to(MAIN_URL);
?>
